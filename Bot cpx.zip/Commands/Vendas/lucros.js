const { Message, MessageEmbed } = require('discord.js')
const { Lucro } = require('../../models/vendas')
const config = require('../../config.json')

/**
 * @param { Message } message
 * @param { string[] } args
 */
const run = async (client, message, args) => {
  if (message.author.id !== config.owner) {
    return
  }
  await message.delete().catch(() => {})

  let guilddb = await Lucro.findOne({
    server_id: message.guildId
  })

  if (!guilddb)
    return message.channel.send({
      embeds: [
        new MessageEmbed()
          .setColor(config.color)
          .setDescription(`${message.guild.name} Não realizou nenhuma venda.`)
      ]
    })

  message.channel.send({
    embeds: [
      new MessageEmbed()
        .setColor(config.color)
        .setTitle(`Lucros da ${message.guild.name}:`)
        .setThumbnail(message.guild.iconURL({ dynamic: true }))
        .addFields(
          {
            name: `Lucro Total:`,
            value: `\`R$${guilddb.lucros}\``,
            inline: true
          },
          {
            name: `Compras Total:`,
            value: `\`${guilddb.comprasrecebidas}\``,
            inline: true
          }
        )
    ]
  })
}
module.exports = {
  run,
  name: 'lucros'
}
