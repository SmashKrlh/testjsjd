const { Message, MessageEmbed } = require('discord.js')
const { Perfil, Lucro } = require('../../models/vendas')
const config = require('../../config.json')

/**
 * @param { Message } message
 * @param { string[] } args
 */
const run = async (client, message, args) => {
  await message.delete().catch(() => {})

  let guilddb = await Lucro.findOne({
    server_id: message.guildId
  })

  if (!guilddb)
    return message.channel.send({
      embeds: [
        new MessageEmbed()
          .setColor(config.color)
          .setDescription(`${message.guild.name} Não realizou nenhuma venda.`)
      ]
    })

  let userdb = await Perfil.find({})
  userdb.sort(a => a.valorgasto)
  userdb.sort((a, b) => b.valorgasto - a.valorgasto)

  userdb = userdb.slice(0, 10)

  message.channel.send({
    embeds: [
      new MessageEmbed()
        .setColor(config.color)
        .setTitle(`Rank de ${message.guild.name}:`)
        .setDescription(
          `${userdb
            .map(
              (user, i) =>
                `${i + 1} | **${
                  client.users.cache.get(user.user_id).username || `sumido#0000`
                }** \`R$${user.valorgasto}\``
            )
            .join('\n> ')}`
        )
        .setThumbnail(message.guild.iconURL({ dynamic: true }))
    ]
  })
}
module.exports = {
  run,
  name: 'rank'
}
