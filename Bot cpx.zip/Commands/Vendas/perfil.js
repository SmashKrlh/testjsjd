const { Message, MessageEmbed } = require('discord.js')
const { Perfil } = require('../../models/vendas')
const config = require('../../config.json')

/**
 * @param { Message } message
 * @param { string[] } args
 */
const run = async (client, message, args) => {
  await message.delete().catch(() => {})

  let user =
    message.mentions.users.first() ||
    client.users.cache.get(args[0]) ||
    message.author

  let userdb = await Perfil.findOne({
    user_id: user.id
  })

  if (!userdb)
    return message.channel.send({
      embeds: [
        new MessageEmbed()
          .setColor(config.color)
          .setDescription(`${user.username} Não realizou nenhuma compra.`)
      ]
    })

  message.channel.send({
    embeds: [
      new MessageEmbed()
        .setColor(config.color)
        .setTitle(`Perfil de ${user.username}:`)
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .addFields(
          {
            name: `Valor Gasto:`,
            value: `\`R$${userdb.valorgasto}\``,
            inline: true
          },
          {
            name: `Compras Feitas:`,
            value: `\`${userdb.compras}\``,
            inline: true
          }
        )
    ]
  })
}
module.exports = {
  run,
  name: 'perfil'
}
